﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PojistovnaFullAspPrzeczek.Data.Migrations
{
    /// <inheritdoc />
    public partial class LoginViewModelRequiredUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
