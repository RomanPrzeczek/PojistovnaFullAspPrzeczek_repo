﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PojistovnaFullAspPrzeczek.Data.Migrations
{
    /// <inheritdoc />
    public partial class LoginRegistrationUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "InsuredPerson",
                columns: table => new
                {
                    IdInsuredPerson = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Surname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    City = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Street = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ZIP = table.Column<int>(type: "int", nullable: false),
                    Phone = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_InsuredPerson", x => x.IdInsuredPerson);
                });

            migrationBuilder.CreateTable(
                name: "Insurance",
                columns: table => new
                {
                    IdInsurance = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    IdInsuredPerson = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Insurance", x => x.IdInsurance);
                    table.ForeignKey(
                        name: "FK_Insurance_InsuredPerson_IdInsuredPerson",
                        column: x => x.IdInsuredPerson,
                        principalTable: "InsuredPerson",
                        principalColumn: "IdInsuredPerson");
                });

            migrationBuilder.CreateTable(
                name: "PersonInsurance",
                columns: table => new
                {
                    IdPersonInsurance = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    InsurancePrice = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectOfInsurance = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    EndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IdInsuranceForPerson = table.Column<int>(type: "int", nullable: false),
                    IdInsuredPerson = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PersonInsurance", x => x.IdPersonInsurance);
                    table.ForeignKey(
                        name: "FK_PersonInsurance_Insurance_IdInsuranceForPerson",
                        column: x => x.IdInsuranceForPerson,
                        principalTable: "Insurance",
                        principalColumn: "IdInsurance",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_PersonInsurance_InsuredPerson_IdInsuredPerson",
                        column: x => x.IdInsuredPerson,
                        principalTable: "InsuredPerson",
                        principalColumn: "IdInsuredPerson",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Insurance_IdInsuredPerson",
                table: "Insurance",
                column: "IdInsuredPerson");

            migrationBuilder.CreateIndex(
                name: "IX_PersonInsurance_IdInsuranceForPerson",
                table: "PersonInsurance",
                column: "IdInsuranceForPerson");

            migrationBuilder.CreateIndex(
                name: "IX_PersonInsurance_IdInsuredPerson",
                table: "PersonInsurance",
                column: "IdInsuredPerson");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PersonInsurance");

            migrationBuilder.DropTable(
                name: "Insurance");

            migrationBuilder.DropTable(
                name: "InsuredPerson");
        }
    }
}
